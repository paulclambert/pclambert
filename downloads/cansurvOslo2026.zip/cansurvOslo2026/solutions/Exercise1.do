// Exercise 1: Different probabilities
//   -- 2026/05/12 
//   -- breast_NW data

cd ${cansurv}/data

// (a)
// First look at the popmort file
// plot the expected mortality rates as a function of age 
// for women in 1990 in the least and most deprived groups.
use popmort_NW, clear
replace rate = rate*100000
twoway (line rate age if year==1990 & sex==1 & dep==1)              ///
       (line rate age if year==1990 & sex==1 & dep==5)              ///
       , legend(order(1 "Least deprived" 2 "Most Deprived")         ///
                ring(0) cols(1) pos(5))                             ///
         yscale(log)                                                ///
         ylabel(100 500 1000 5000 10000 20000 50000, format(%6.0f)) ///
         xtitle("Age") ytitle("Mortality per 100,000 py")           ///
         title("Mortality rates in England for women in 1990")

// (b) 
// Load the breast_NW dataset keeping only those in the least (dep=1) and 
// most deprived (dep=5) groups. 

use breast_NW, clear
keep if inlist(dep,1,5)

// Estimate the all-cause survival function by age group (agegrp)
// stset 
stset survtime, f(dead==1) id(ident)

// Kaplan-Meier all-cause survival curve
sts graph, by(agegrp)             ///
           legend(ring(0) pos(1)) ///
           xlabel(0(1)10)

// (c)
// Use stpp to estimate the all-cause, net, and crude probabilities 
// of death by age group.
stpp Net using popmort_NW,                        ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(agegrp)                               /// stratify by age groups
         allcause(AC)                             /// calculate all-cause
         crudeprob(CPc CPo)                       /// calculate crude probs
         deathprob                                /// probs of death
         list(1 5 10)                             /// list at 1,5,10 years
         frame(probs, replace)                    //  save summary to frame

// List summary
frame probs: list agegrp time PP AC CP_can CP_oth, ///
                  noobs sepby(agegrp)

// (i) For women aged 75+ explain why PP is greater than CP_can.

// (ii) Why are AC, PP and CP_can so similar for women aged <45?

// (d)
// Show that the sum of the crude probability of death due to cancer
// and the crude probability of death due to other causes gives the
// all cause probability of death.
frame probs: gen double AC2 = CP_can + CP_oth
frame probs: list agegrp time AC AC2, noobs sepby(agegrp)

// (e)
// What proportion of women in each age group die to cancer at 1, 5 amd 10 years?
frame probs: gen prob_can = CP_can/AC2
frame probs: list agegrp time PP AC CP_can CP_oth prob_can, noobs sepby(agegrp)

// Plot the crude probabilities in a stacked graph to see may of these issues.
foreach a in 1 5 {
  local title: label agelab `a'
  twoway (rarea AC CPc _t if agegrp==`a', sort color(%40))  ///
         (area CPc _t if agegrp==`a', sort color(%40))      ///
         (line Net _t if agegrp==`a', sort lcolor(black)),  ///
         title("`title'")                                   ///
         xtitle("Time from diagnosis (years)")              ///
         ytitle("Probability of death")                     ///
         xlabel(0(1)10)                                     ///
         ylabel(0(0.2)1, format(%3.1f))                     ///
         legend(order(2 "Cancer" 1 "Other" 3 "Net")         ///
                pos(6) cols(3))                             ///
         plotregion(margin(zero))                           ///
         name(age`a', replace)                              //
}
grc1leg age1 age5, ycommon
 

