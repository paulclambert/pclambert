// Exercise 2: Age Standardization
//   -- 2026/05/12 
//   -- breast_NW data

cd ${ROOT}/data


// (a) All cause survival by deprivation group
use breast_NW, clear

// restrict to least and most deprived groups 
keep if inlist(dep,1,5)

// stset data
stset survtime, f(dead==1) id(ident)

// Plot the Kaplan-Meier curves
sts graph, by(dep)                ///
           legend(ring(0) pos(1)) ///
           xlabel(0(1)10)

//  (i) List two problems with this if we are interested in comparing cancer 
//      mortality.


// (b)
// Compare the age distributions of the two deprivation groups. 
// Do you think age standardization will increase or decrease the 
// difference in survival between the two groups? Why?
mean agediag, over(dep)
tab dep agegrp, row

// (c)
// Calculate unadjusted Pohar Perme estimates
stpp Net_unadj using popmort_NW,                  ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(1 5 10)                             /// list at 1,5,10 years
         frame(unadj, replace)                    //  save summary to frame

// (d)
// Calculate age standardized estimates using the ICSS1 age weights
// The weights in each age group are 0.07, 0.12, 0.23, 0.29, 0.29
stpp Net_ICSS using popmort_NW,                   ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(1 5 10)                             /// list at 1,5,10 years
         standstrata(agegrp)                      /// variable to standadrize by
         standweights(0.07 0.12 0.23 0.29 0.29)   /// standardiztion weights
         frame(ICSS, replace)                      //  save summary to frame

frame unadj: list, noobs sepby(dep)
frame ICSS:  list, noobs  sepby(dep)

// Compare to the unadjusted estimates. 
//   -- Why do both groups now have lower survival?

// (e)
// Now perform the age standardization using individual weights
// Calculate the individal weights using genindweights.
genindweights wt_ICSS, by(dep) agegroup(agegrp) refexternal(ICSS1_5)

// (i)  When are the weights <1 and when are the greater than 1?
// (ii) Why is the range of the weights more varied for the least deprived compared 
// to the most deprived?

// (iii) Use the indweights() option in stpp
stpp Net_ICSS_ind using popmort_NW,               ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(1 5 10)                             /// list at 1,5,10 years
         indweights(wt_ICSS)                      /// individual weights
         frame(ICSS_ind, replace)      

frame ICSS:     list, noobs sepby(dep)
frame ICSS_ind: list, noobs sepby(dep)
 
// The estimates are veyr similar. Why is this not surprising?

// (f)
// Now age standardize to the combined age distribution of the 
// two deprivation groups.
genindweights wt_comb, by(dep) refconditional(.,strata(agegrp))

// (i) Why are the weights less varied than when using the ICCS weights


// (ii) Use the indweights() option in stpp
stpp Net_comb using popmort_NW,                   ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(1 5 10)                             /// list at 1,5,10 years
         indweights(wt_comb)                      /// individual weights
         frame(comb, replace)    

// Compare to the unadjusted estimates.
//   -- Has age standardization impacted on the differences?
frame unadj: list, noobs sepby(dep)
frame comb:  list, noobs sepby(dep)


// (g) 
// We could age standardize to the age distribution of one group.
//  -- age standardize to the age distribution of the most deprived group

// First generate the weights.
genindweights wt_dep5, by(dep) refconditional(dep==5,strata(agegrp))
// (i) Why are the weights 1 for the most deprived group?

// (h)
// Now feed the weights into stpp
stpp Net_dep5 using popmort_NW,                   ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(1 5 10)                             /// list at 1,5,10 years
         indweights(wt_dep5)                      /// individual weights
         frame(dep5, replace)  

// (ii) Why are the unadjusted and the latest age standardized estimates identical
//      for the most deprived group?
frame unadj: list, noobs sepby(dep)
frame dep5:  list, noobs sepby(dep)

// (h) Compare the age standardized estimates on the same graph
twoway (line Net_unadj Net_ICSS_ind Net_comb Net_dep5 _t if dep==1, sort), ///
       legend(order(1 "Unadjusted" 2 "ICSS" 3 "Combined" 4 "Most deprived") ring(0) pos(1)) ///
       ytitle("Net survival") xtitle("Time from diagnosis (years)") ///
       ylabel(,format(%3.1f)) xlabel(0(1)10)

