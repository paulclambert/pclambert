// Exercise 3: Reference Adjustment
//   -- 2026/05/12 
//   -- breast_NW data

cd ${cansurv}/data


use breast_NW, clear


// restrict to least and most deprived groups 
keep if inlist(dep,1,5)



// stset data
stset survtime, f(dead==1) id(ident)

// (a)
// Obtain unadjusted estimates of net and all cause survival and crude probabilities of death

// net, crude and all cause estimates by deprivation group.
stpp Net using popmort_NW,                        ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         allcause(AC)                             /// calculate all-cause
         crudeprob(CPc CPo)                       /// calculate crude probs
         list(1 5 10)                             /// list at 1,5,10 years
         by(dep)                                  /// by deprivation group
         frame(unadj, replace)                    //  save summary to frame

// If all assumptions are valid, what are potential reasons for differences between 
// the deprivation groups for
//   (i)  net survival
//   (ii) all cause survival and the crude probability of death due to cancer


// (b)
// Generate individual weights in order to age standardize to the age distribution 
// of both deprivation groups combined.
genindweights wt_comb, by(dep) refconditional(.,strata(agegrp))

// Obtain the age standardized age standardized estimates of net and all cause survival, 
// and the crude probabilities of death.
stpp Net_s using popmort_NW,                      ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         allcause(AC_s)                           /// calculate all-cause
         crudeprob(CPc_s CPo_s)                   /// calculate crude probs
         list(1 5 10)                             /// list at 1,5,10 years
         by(dep)                                  /// by deprivation group
         indweights(wt_comb)                      ///
         contrast(difference, baselevel(dep 1))   /// difference
         frame(stand, replace)                    //  save summary to frame

// If all assumptions are valid, what are potential reasons for differences between 
// the deprivation groups for
//   (i)  net survival
//   (ii) all cause survival and the crude probability of death due to cancer

// (c)
// Create reference rates for both deprivation groups combined.
preserve
  use popmort_NW, clear
  keep if inlist(dep,1,5) 
  // average survival over deprivation groups
  collapse (mean) survprob, by(age year sex)
  gen rate = -ln(survprob)
  save popmort_ref_comb, replace
restore

// (d)
// Calculate the reference adjusted all-cause and crude probabilities of
// death. The reference rates are passed to stpp using the popmort2() option.
stpp Net_ra using popmort_NW,                     ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         allcause(AC_ra)                          /// calculate all-cause
         crudeprob(CPc_ra CPo_ra)                 /// calculate crude probs
         list(1 5 10)                             /// list at 1,5,10 years
         by(dep)                                  /// by deprivation group
         indweights(wt_comb)                      ///
         contrast(difference, baselevel(dep 1))   /// difference
         popmort2(popmort_ref_comb,               /// reference popmort file
                  pmother2(sex))                  ///
         frame(refadj, replace)                   //  save summary to frame

// what are potential reasons for differences between the deprivation groups for
//   (i) all cause survival and the crude probability of death due to cancer

frame unadj:  list dep time AC CP_can if time==10, noobs sepby(dep)
frame stand:  list dep time AC CP_can if time==10, noobs sepby(dep)
frame refadj: list dep time AC CP_can if time==10, noobs sepby(dep)

// list the difference in standardized net survival and
// reference adjusted crude probabilities
frame stand:  list time PP_diff*  if dep==5, noobs abbrev(12)
frame refadj: list time AC_diff*  if dep==5, noobs abbrev(12)

// Compare the width of the 95% CIs. Why are the widths of the 95% CIs narrower
// for long term all-cause survival?

// 
// We will see how robust the reference adjusted estimates are to the choice 
// of reference rates. 
// For simplicity we will increase all rates by 20\% and assess their impact 
// on net survival and reference adjusted all-cause survival.

// (i) popmort file with correct rates
preserve
use popmort_NW, clear
replace rate = rate*1.2
replace survprob = exp(-rate)
save popmort_wrong, replace
restore

// (ii) reference expected rates using 'incorrect' rates.
preserve
use popmort_wrong, clear
keep if inlist(dep,1,5) 
collapse (mean) survprob, by(age year sex)
gen rate = -ln(survprob)
save popmort_ref_wrong, replace
restore

// (iii) Net survival using incorrect rates
stpp Net_s_w using popmort_wrong,                 ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         allcause(AC_s_w)                         /// calculate all-cause
         crudeprob(CPc_s_w CPo_s_w)               /// calculate crude probs
         list(1 5 10)                             /// list at 1,5,10 years
         by(dep)                                  /// by deprivation group
         indweights(wt_comb)                      ///
         frame(stand_w, replace)                  //  save summary to frame

// compare net survival
frame stand:    list time PP PP_lci PP_uci  , noobs sepby(dep)
frame stand_w:  list time PP PP_lci PP_uci  , noobs sepby(dep)

// (iii) Referennce adjusted survival using incorrect rates
stpp Net_ra_w using popmort_wrong,                ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         allcause(AC_ra_w)                        /// calculate all-cause
         crudeprob(CPc_ra_w CPo_ra_w)             /// calculate crude probs
         list(1 5 10)                             /// list at 1,5,10 years
         by(dep)                                  /// by deprivation group
         indweights(wt_comb)                      ///
         popmort2(popmort_ref_wrong,              /// reference popmort file
                  pmother2(sex ))                 ///
         frame(refadj_w, replace)                 //  save summary to frame


// compare reference adjusted survival
frame refadj:    list time AC AC_lci AC_uci  , noobs sepby(dep)
frame refadj_w:  list time AC AC_lci AC_uci  , noobs sepby(dep)

// Note that reference adjusted crude probalities are much more affected by different expected rates
frame refadj:    list time CP_can CP_can_lci CP_can_uci  , noobs sepby(dep)
frame refadj_w:  list time CP_can CP_can_lci CP_can_uci  , noobs sepby(dep)