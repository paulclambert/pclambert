// Exercise 4: Period Analysis
//   -- 2026/05/12 
//   -- breast_NW data

cd ${ROOT}/data

// (a)
use breast_NW, clear

// restrict to least and most deprived groups 
keep if inlist(dep,1,5)

// (i) We will restrict follow-up to the end of 1990 (the last year of diagnosis)
//     to match the situation where period analysis is usually applied.
gen dateexit2 = min(dateexit,mdy(12,31,1990))
replace datediag=mdy(12,30,1990) if datediag==mdy(12,31,1990) // avoid 0 survival
gen dead2     = cond(dateexit==dateexit2,dead,0)

// stset for standard analysis using dates 
stset dateexit2, failure(dead2==1) origin(datediag) id(ident) scale(365.25)

// (ii) Age standardize to the age distribution in 1990.
//      Calculate the individual weights
genindweights wt_1990, by(dep) refconditional(year(datediag)==1990,strata(agegrp))

// (iii) Obtain age standardized estimates of net survival.
stpp Net_cohort using popmort_NW,                 ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(0 1 5)                              /// list at 1,5,10 years
         indweights(wt_1990)                      /// individual weights
         frame(cohort, replace)    

// (b) Perform a period analysis where the period window is defined by the 
//     start and end of 1990

// stet using the enter() option.
stset dateexit, failure(dead==1) origin(datediag) id(ident) scale(365.25) ///
                enter(time mdy(1,1,1990))                 

// (i) From the stset output, how many individual died or were censored before the
//     start of the period window


// (ii) Compare the age group distribution between those included in the analysis 
//     (_st==1) and those diagnosed in the period window (_st==1 & _t0==0)
tab agegrp if _st
tab agegrp if _st & _t0==0
// Why is there lower proportion in the oldest age group for all those at risk in the
// period window compared to those diagnosed in the period window?

// We are now analysing a subset of the data, so the proportions in each age groups
// will have changed. It is important to recalculate the individual weights


// (iii) Recalculate the individual weights. For the observed age distribution it 
//       is important to use the age distribution of those diagnosed in the period window. 
//       Use the restrict option of genindweights to calculate the individual weights, 
//       where the restriction is those diagnosed in 1990.
genindweights wt_1990p if _st, by(dep) refconditional(year(datediag)==1990,strata(agegrp)) ///
                       restrict(_t0==0)

// (c)
// Calculate the period estimates of net survival
stpp Net_period using popmort_NW,                 ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(0 1 5 )                             /// list at 1,5,10 years
         indweights(wt_1990p)                     /// individual weights
         frame(period, replace)    

frame cohort: list, noobs sepby(dep)
frame period: list, noobs sepby(dep)

// Compare the estimates: How much has survival increased using the period estimates


// (d) We actually have 5 year follow-up for those diagnosed in 1990.
//     Compare the predictions from period analysis with what actually happened.

stset dateexit, failure(dead==1) origin(datediag) id(ident) scale(365.25)

// As we are analysing a subset of the data, we need to recalculate the 
// individual weights

genindweights wt_1990d if year(datediag)==1990, by(dep) ///
              refconditional(year(datediag)==1990,strata(agegrp)) 

// 
stpp Net_1990 using popmort_NW                    ///
         if year(datediag)==1990,                 /// restrict to 1990
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         by(dep)                                  /// stratify by age groups
         list(0 1 5 )                             /// list at 1,5,10 years
         indweights(wt_1990d)                     /// individual weights
         frame(diag1990, replace)    

frame period:   list, noobs sepby(dep)
frame diag1990: list, noobs sepby(dep)

// (i)  Compare the period estimates with those diagnosed in 1990
// (ii) What are potential reasons for differences




