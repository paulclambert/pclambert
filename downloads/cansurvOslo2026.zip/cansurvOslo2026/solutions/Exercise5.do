// Exercise 5: Simple flexible parametric models
//   -- 2026/05/19 
//   -- breast_NW data

clear frames
cd ${cansurv}/data

// (a)
use breast_NW, clear
keep if inlist(dep,1,5) 
keep if agediag<70

// stset 
stset survtime, f(dead==1) id(ident) exit(time 5)


// (i) Fir a proportional hazards model
stpm3 i.dep, scale(lncumhazard) df(5) eform
estimates store ph

// (ii) Compare to a Cox model
stcox i.dep,

// (iii) Compare model based survival estimates with non-parametric JKaplan-Meier estimates
estimates restore ph
stpm3km i.dep, legend(order(1 "Least deprived" 2 "Most deprived") pos(1) ring(0)) ///
               ylabel(0(0.2)1, format(%3.1f)) xlabel(0(1)5)                       ///
               xtitle("Time since diagnosis (years)")                             ///
               ytitle("Proportion Alive")                                         ///
               name(ph, replace)
// What is the most likely reason for differences between the model based and non-parametric estimates?

// (b)
// Fit models with betwen 1 and 10 df for the baseline
forvalues df = 1/10 {
  stpm3 i.dep, scale(lncumhazard) df(`df') eform
  estimates store mod_df`df'
}

// (i)  Compare the hazard ratios.
// (ii) Which model has the lowest AIC and BIC.
estimates table mod_df*, keep(5.dep) se eform stats(AIC BIC)

// (c)
// predict survival functions 
forvalues df = 1/10 {
  estimates restore mod_df`df'
   predict S1_df`df' S5_df`df', surv frame(survpred, mergecreate) ///
                                timevar(0 5, step(0.1))           ///
                                at1(dep 1) at2(dep 5)
}

// (i) plot survival functions
// 1, 3 and 5 df
frame survpred{
  twoway (line S1_df1 S1_df3  S1_df5 tt) ///
         (line S5_df1 S5_df3  S5_df5 tt) ///
         , legend(ring(0) pos(1))        ///
           name(compare_surv1, replace)
}
// 6, 8 and 10 df
frame survpred {
  twoway (line S1_df6 S1_df8  S1_df10 tt)  ///
         (line S5_df6 S5_df8  S5_df10 tt)  ///
         , legend(ring(0) pos(1))          ///
           name(compare_surv2, replace)
}

// predict hazard functions
forvalues df = 1/10 {
  estimates restore mod_df`df'
   predict h1_df`df' h5_df`df', hazard frame(hazpred, mergecreate) ///
                                timevar(0 5, step(0.1))           ///
                                at1(dep 1) at2(dep 5)
}
graph combine compare_surv1 compare_surv2, ycommon

// (ii) plot survival functions
// 1, 3 and 5 df
frame hazpred {
  twoway (line h1_df1 h1_df3  h1_df5 tt)  ///
         (line h5_df1 h5_df3  h5_df5 tt)  ///
         , legend(ring(0) pos(1))        ///
           name(compare_haz1, replace)
}

// 6, 8 and 10 df
frame hazpred {
  twoway (line h1_df6 h1_df8  h1_df10 tt)  ///
         (line h5_df6 h5_df8  h5_df10 tt)  ///
         , legend(ring(0) pos(1))        ///
           name(compare_haz2, replace)
}
graph combine compare_haz1 compare_haz2, ycommon

// (d)
// Relax the proportional hazards assumption by fitting an interaction 
// between deprivation group and time. Use 3df for the interaction.
stpm3 i.dep, scale(lncumhazard) df(5) tvc(i.dep) dftvc(3)
estimates store tvc

// (i) Is there evidence that the model with non-proportional hazards is a better fit?
lrtest ph tvc

// (ii) Compare the fitted survival curves with the Kaplan-Meier curves 
stpm3km i.dep, legend(order(1 "Least deprived" 2 "Most deprived") pos(1) ring(0)) ///
               ylabel(0(0.2)1, format(%3.1f)) xlabel(0(1)5)                       ///
               xtitle("Time since diagnosis (years)")                             ///
               ytitle("Proportion Alive")                                         ///
               name(tvc, replace)
graph combine ph tvc, name(ph_tvc, replace)


// (iii) Plot the time-dependent hazard ratio
predict h1 h5, at1(dep 1) at2(dep 5) timevar(0.05 5, step(0.05)) hazard ///
            contrast(ratio) contrastvar(hr) ci frame(hr, replace)

frame hr {
  twoway    (rarea hr_lci hr_uci tt, color(%30))   ///
            (line hr tt, sort pstyle(pline1))      ///
          , legend(off)                            ///
            xtitle("Time since diagnosis (years)") ///
            ytitle("Hazard ratio")                 ///
            name(hr, replace)
}

