// Exercise 6: Flexible parametric survival models
//   -- extended functions and standardization
//   -- 2026/05/19 
//   -- breast_NW data

cd ${cansurv}/data

// (a)
use breast_NW, clear
keep if inlist(dep,1,5) 
stset survtime, f(dead==1) id(ident) exit(time 5)

// (i) Model with age at diagnosis assuming linearity.
stpm3 agediag, df(5) scale(lncumhazard)
estimates store linear

// (ii) Use the stpm3km command to see how well the model fits within 
//     age groups (agegrp).
stpm3km i.agegrp, ///
     legend(order(6 7 8 9 10) pos(7) ring(0))                ///
               ylabel(0(0.2)1, format(%3.1f)) xlabel(0(1)5)  ///
               xtitle("Time since diagnosis (years)")        ///
               ytitle("Proportion Alive")                    ///
               name(linear, replace)
// Do you think linearity is a reasonable assumption?

// (b)
// Now relax the linearity assumption for age at diagnosis by using 
// natural splines with 4 d.f.
stpm3 @ns(agediag,df(4)), df(5) scale(lncumhazard)
estimates store non_linear
// (i) Is there any point trying to interpret the model parameters individually?


// (ii) Use the stpm3km command to see how well the model fits within 
//      age groups (agegrp).
stpm3km i.agegrp, ///
     legend(order(6 7 8 9 10) pos(7) ring(0)) ///
               ylabel(0(0.2)1, format(%3.1f)) xlabel(0(1)5)                       ///
               xtitle("Time since diagnosis (years)")                             ///
               ytitle("Proportion Alive")                                         ///
               name(non_linear, replace)
// Have things improved compared to assuming linearity?

// (ii) likekihood ratio test
lrtest linear non_linear

// (c) Now relax the proportional hazards assumption by including a natural cubic spline
//     function for age at diagnosis as as a time-dependent effect.
stpm3 @ns(agediag,df(4)), df(5) scale(lncumhazard)         ///
                          tvc(@ns(agediag,df(3))) dftvc(3)
estimates store non_linear_tvc

// (i) Use the stpm3km command to see how well this model fits within age groups (agegrp).
//     Have things improved?
stpm3km i.agegrp, ///
     legend(order(6 7 8 9 10) pos(7) ring(0)) ///
               ylabel(0(0.2)1, format(%3.1f)) xlabel(0(1)5)                       ///
               xtitle("Time since diagnosis (years)")                             ///
               ytitle("Proportion Alive")                                         ///
               name(non_linear_tvc, replace)

// (ii) likekihood ratio test
lrtest non_linear non_linear_tvc


// (d) Now fit a model that also includes the effect of deprivation. 
//     Relax the proportional hazard assumption for both age at diagnosis 
//     and deprivation group.

stpm3 @ns(agediag,df(4))##i.dep, df(5) scale(lncumhazard) ///
                                 tvc(@ns(agediag,df(3)) i.dep) dftvc(3)

// (i) Predict survival for a 40, 50, 60 and 70 year old women 
//     in each deprivation group.
predict S40_d1 S50_d1 S60_d1 S70_d1, surv ci frame(surv_age, replace)            /// 
                                     timevar(0 5, step(0.05))                    ///
                                     at1(agediag 40 dep 1) at2(agediag 50 dep 1) ///
                                     at3(agediag 60 dep 1) at4(agediag 70 dep 1)

predict S40_d5 S50_d5 S60_d5 S70_d5, surv ci frame(surv_age, merge)              ///
                                     at1(agediag 40 dep 5) at2(agediag 50 dep 5) ///
                                     at3(agediag 60 dep 5) at4(agediag 70 dep 5)

// (ii) How does age and deprivation group impact on survival?
frame surv_age {
  twoway (line S40_d1 S40_d5 tt, pstyle(p1line..) lpattern(solid shortdash)) ///
         (line S50_d1 S50_d5 tt, pstyle(p2line..) lpattern(solid shortdash)) ///
         (line S60_d1 S60_d5 tt, pstyle(p3line..) lpattern(solid shortdash)) ///
         (line S70_d1 S70_d5 tt, pstyle(p4line..) lpattern(solid shortdash)) ///
          ,

}



// (e)
// We will now compare depivation groups by obtaining marginal (average) 
// survival estimates. As we are only modelling age and deprivation these 
// will be age standardized estimates. We will age standardize to the 
// joint age distribution of the two deprivation groups.

// (i) is there a difference in the age distribution between the two 
//     deprivation groups.
tab dep agegrp, row
table dep, stat(mean agediag) nototal


// (ii) Use the standsurv commands to obtain the marginal survival estimates and their
difference.
// standardize survival and difference
// standardizing to age distribution of both groups combined.
range tt 0 5 101
standsurv S1 S5, surv ci timevar(tt) frame(surv_stand, replace) ///
                 at1(dep 1) at2(dep 5)                          ///
                 contrast(difference)                           ///
                 contrastvar(Sdiff)
// How many survival curves have been estimated in the backgound to obtain 
// the marginal estimates?

// (iii) Plot the standardized survival curves. 
frame surv_stand {
  twoway (rarea S1_lci S1_uci tt, pstyle(p1line) color(%30)) ///
         (rarea S5_lci S5_uci tt, pstyle(p2line) color(%30)) ///
         (line S1 tt, pstyle(p1line))                        ///
         (line S5 tt, pstyle(p2line))                        ///
         ,  xtitle("Time since diagnosis (years)")           ///
            ytitle("Proportion Alive")                       ///
            legend(order(3 "Least deprived" 4 "Most deprived") ///
                   ring(0) pos(1))
}
// Why would you expect these to be different to the Kaplan-Meier curves?

// (iv) Plot the difference in the standardized survival curves.
frame surv_stand {
  twoway (rarea Sdiff_lci Sdiff_uci tt, pstyle(p1line) color(%30)) ///
         (line Sdiff tt, pstyle(p1line))                           ///
         ,  xtitle("Time since diagnosis (years)")                 ///
            ytitle("Difference in survival probability")           ///
            legend(off)
}




