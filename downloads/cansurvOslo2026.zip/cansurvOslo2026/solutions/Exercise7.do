// Exercise 7: Flexible parametric relative survival models
//   -- 2026/05/19 
//   -- breast_NW data

frames reset
cd ${cansurv}/data

// (a)
// Load the breast_NW dataset keeping only those in the least (dep=1) and 
// most deprived (dep=5) groups. We will restrict follow-up to 10 years 
// after diagnosis.
use breast_NW, clear
keep if inlist(dep,1,5) 

stset survtime, f(dead==1) id(ident) exit(time 10)

// (i) Merge in the expected rates at the time and date of death/censoring 
//     from the \texttt(popmort_NW) file.
gen age = int(min(agediag + _t,99))
gen year = year(datediag+ _t*365.24)

merge m:1 sex dep year age using popmort_NW, ///
          keepusing(rate) keep(match master)


// (ii) First fit an all cause model without any covariates. Compare the 
//      model-based estimate with a Kaplan-Meier estimate. 
//      Is there good agreement?
stpm3, scale(lncumhazard) df(5)

// simple way to overlay model based and KM estimate
gen cons=1
stpm3km i.cons,


// (iii) Fit a relative survival model without covariates. Compare the 
//       model-based estimate with a Pohar Perme estimate. 
//       Is there good agreement?      
stpm3, scale(lncumhazard) df(5) bhazard(rate)
range tt 0 10 101
// use standsurv so can merge other models to the same frame
standsurv Net_model, survival  timevar(tt) frame(models, replace) ///
                     at1(.)

// Pohar Perme estimate
stpp Net using popmort_NW,                        ///
         agediag(agediag) datediag(datediag)      /// age and date of diagnosis
         pmother(sex dep) pmage(age) pmyear(year) /// variables in popmort file
         list(1 5 10)                             /// list at 1,5,10 years
         frame(net, replace)                      //  save summary to frame

// graph 
twoway (line Net _t, sort connect(stairstep)) 
frame models: addplot: (line Net_model tt, sort)



// (b) Fit a relative survival model that incorporates age at diagnosis as
//     non-linear and time-dependent effect.

stpm3 @ns(agediag,df(4)), scale(lncumhazard) df(5) bhazard(rate) ///
                          tvc(@ns(agediag,df(4))) dftvc(3)
// (i) Use standsurv to obtain a marginal estimate of net survival
standsurv Net_model_ns, survival frame(models, merge)

// (ii) Has the agreement improved?
twoway (line Net _t, sort connect(stairstep)) 
frame models {
  addplot: line Net_model Net_model_ns tt
}


// (c)  Now add deprivation group to the model. Allow the effect of age to 
//      vary between deprivation groups and allow the effect of deprivation 
//      to be time-dependent.
stpm3 @ns(agediag,df(4))##i.dep, scale(lncumhazard) df(5) bhazard(rate) ///
                          tvc(@ns(agediag,df(4)) i.dep) dftvc(3)


// (i) Obtain an estimate of 5 year relative survival as a function of age for 
//     each deprivation group.

// predictions
cap frame drop agepred
frame create agepred
frame agepred {
  range agediag  18 90 73
  gen dep=. 
  gen t5 = 5
  predict RS5_dep1 RS5_dep5, surv ci timevar(t5) merge ///
                             at1(dep 1, obsvalues)     ///
                             at2(dep 5, obsvalues)     ///
                             contrast(difference)      ///
                             contrastvar(S5_diff)
}

// plot
frame agepred {
  twoway (rarea RS5_dep1_lci RS5_dep1_uci agediag, color(%30) pstyle(p1line))  ///
         (line  RS5_dep1 agediag,  pstyle(p1line))                             /// 
         (rarea RS5_dep5_lci RS5_dep5_uci agediag, color(%30) pstyle(p2line))  ///
         (line  RS5_dep5 agediag,  pstyle(p2line))                             /// 
         , legend(order(2 "Least deprived" 4 "Most deprived") ring(0) pos(6))  ///
           ylabel(0(0.2)1, format(%3.1f))                                      ///
           xtitle("Age at diagnosis (years)")                                  ///
           ytitle("Net survival")                                              ///
           name(net, replace)
}



// (ii) Obtain an estimate of 5 year all-cause survival as a function of age 
//      for each deprivation group.

frame agepred {
  gen sex=2
  predict AC5_dep1 AC5_dep5, surv ci timevar(t5) merge                  ///
                             at1(dep 1, obsvalues)                      ///
                             at2(dep 5, obsvalues)                      ///
                             contrast(difference)                       ///
                             contrastvar(AC_diff)                       ///
                             expsurv(using(popmort_NW) agediag(agediag) ///
                                     datediag(1990-1-1) pmage(age)      ///
                                     pmyear(year) pmother(sex dep)      ///
                                     pmmaxyear(1990)                    ///  
                                     at1(dep 1) at2(dep 5))
}

// plot
frame agepred {
  twoway (rarea AC5_dep1_lci AC5_dep1_uci agediag, color(%30) pstyle(p1line))  ///
         (line  AC5_dep1 agediag,  pstyle(p1line))                             /// 
         (rarea AC5_dep5_lci AC5_dep5_uci agediag, color(%30) pstyle(p2line))  ///
         (line  AC5_dep5 agediag,  pstyle(p2line))                             /// 
         , legend(order(2 "Least deprived" 4 "Most deprived") ring(0) pos(6)) ///
           ylabel(0(0.2)1, format(%3.1f))                                     ///
           xtitle("Age at diagnosis (years)")                                 ///
           ytitle("All cause survival")                                       ///
           name(ac, replace)
}

graph combine net ac


// (d)
// We will now obtain standardized estimates of net and all cause survival.

// (i) Use standsurv to obtain the marginal net survival estimates by 
//     deprivation group. Age standardize to the combined age distribution.
standsurv RS1 RS5, surv ci timevar(tt) frame(stand, replace) ///
                   at1(dep 1) at2(dep 5)

// (ii) Use standsurv to obtain the marginal all-cause estimates by 
//      deprivation group. Age standardize to the combined age distribution.
standsurv AC1 AC5, surv ci  frame(stand, merge)                  ///
                   at1(dep 1) at2(dep 5)                         ///
                   expsurv(using(popmort_NW) agediag(agediag)    ///
                           datediag(datediag) pmage(age)         ///
                           pmyear(year) pmother(sex dep)         ///
                           pmrate(rate) pmmaxyear(1995)          ///
                           at1(dep 1) at2(dep 5))


// plot net
frame stand {
  twoway (rarea RS1_lci RS1_uci tt, color(%30) pstyle(p1line))                ///
         (line RS1 tt, pstyle(p1line))                                        ///
         (rarea RS5_lci RS5_uci tt, color(%30) pstyle(p2line))                ///
         (line RS5 tt, pstyle(p2line))                                        ///
         , legend(order(2 "Least deprived" 4 "Most deprived") ring(0) pos(6)) ///
           ylabel(0(0.2)1, format(%3.1f))                                     ///
           xtitle("Time from diagnosis (years)")                              ///
           ytitle("Net survival")                                             ///
           name(net_stand, replace)                          
}

// plot all-cause
frame stand {
  twoway (rarea AC1_lci AC1_uci tt, color(%30) pstyle(p1line))                ///
         (line AC1 tt, pstyle(p1line))                                        ///
         (rarea AC5_lci AC5_uci tt, color(%30) pstyle(p2line))                ///
         (line AC5 tt, pstyle(p2line))                                        ///
         , legend(order(2 "Least deprived" 4 "Most deprived") ring(0) pos(6)) ///
           ylabel(0(0.2)1, format(%3.1f))                                     ///
           xtitle("Time from diagnosis (years)")                              ///
           ytitle("All cause survival")                                       ///
           name(ac_stand, replace)                          
}

graph combine net_stand ac_stand