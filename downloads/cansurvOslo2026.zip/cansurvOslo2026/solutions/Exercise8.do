// Exercise 8: Loss in expectation of life
//   -- 2026/05/19 
//   -- breast_NW data

frames reset
cd ${cansurv}/data

// (a)
// Load the \texttt{colon} dataset keeping only those diagnosed 1975-84. 
// We will use the data to assess how well the models can extrapolate. 
use colon, clear
keep if year8594 ==0
drop if agegrp==0

stset exit, failure(status=1,2) scale(365.25) origin(dx) ///
            exit(time mdy(12,31,1985))                   


// (i) Fit an all cause model. Use natural splines to model the effect of age 
//     and also incorporate as a time-dependent effect.
stpm3 @ns(age,df(3)), scale(lncumhazard) df(5) tvc(@ns(age,df(3))) dftvc(3)
estimates store allcause


// (ii) There is an an additional 10 years follow-up, so evaluate how well 
//      the model extrapolates the marginal survival during this period 
//      by comparing to the Kaplan-Meier estimate.

stset exit, failure(status=1,2) scale(365.25) origin(dx) 
range tt 0 80 501
standsurv S_ac, surv at1(.)  timevar(tt)  ///
             frame(marg, replace)     
sts graph, legend(on)
frame marg: addplot: line S_ac tt, pstyle(p1line) lpattern(dash..) ///
                     xtitle("Time from diagnosis (years)")         ///
                     ytitle("Proportion alive")                    ///
                     xline(10, lcolor(gs7) lpattern(dash))         ///
                     legend(order(1 "KM" 2 "Model"))                 
// Does the extrapolation look reasonable?

// (iii) It is harder to extrapolate for younger people than older people.
//       How well does the extrapolation work for different agegroups
standsurv S_ac*, surv over(agegrp)  timevar(tt)  ///
                frame(marg_agegrp, replace)      
sts graph, by(agegrp) legend(ring(0) pos(1))
frame marg_agegrp: addplot: line S_ac*  tt, pstyle(p1line p2line p3line)    ///
                                      lpattern(dash..)                      /// 
                                      xtitle("Time from diagnosis (years)") ///
                                      ytitle("Proportion alive")            ///
                                      xline(10, lcolor(gs7) lpattern(dash)) ///
                                      legend(order(1 2 3 ))                 ///
                                      note("Dashed lines are model based")                      


// (b) We will repeat the extrapolation, but now do this after fitting a
//     relative survival model.

// (i) Merge in the expected rates at the time and date of death/censoring 
//     from the popmort file.
stset exit, failure(status=1,2) scale(365.25) origin(dx) ///
            exit(time mdy(12,31,1985))                   


gen _age = int(min(age + _t,99))
gen _year = year(dx + _t*365.24)

merge m:1 sex _year _age using popmort, ///
          keepusing(rate) keep(match master)

// (ii) Fit the same model as the all-cause  model in terms of how you model age,
//      but add the bhazard(rate) option to make it a relative survival model
stpm3 @ns(age,df(3)), scale(lncumhazard) df(5) ///
                      tvc(@ns(age,df(3))) dftvc(3) bhazard(rate)


// (iii) Has the extrapolation of marginal all cause survival improved?
stset exit, failure(status=1,2) scale(365.25) origin(dx) 

standsurv S_rs, surv at1(.)  ///
             frame(marg, merge)      ///
             expsurv(using(popmort)    ///
             agediag(age) datediag(dx) ///
             pmother(sex)              ///
             pmrate(rate)              ///
             pmage(_age) pmyear(_year) ///
             pmmaxage(99) pmmaxyear(1995))


sts graph
frame marg: addplot: line S_rs tt, pstyle(p1line) lpattern(dash..) ///
                     xtitle("Time from diagnosis (years)")         ///
                     ytitle("Proportion alive")                    ///
                     xline(10, lcolor(gs7) lpattern(dash))         ///
                     legend(order(1 "KM" 2 "Model"))                 


// (iv) Has the extrapolation of age group specific all cause survival improved?

standsurv S_rs*, surv over(agegrp)    ///
             frame(marg_agegrp, merge)      ///
             expsurv(using(popmort)    ///
             agediag(age) datediag(dx) ///
             pmother(sex)              ///
             pmrate(rate)              ///
             pmage(_age) pmyear(_year) ///
             pmmaxage(99) pmmaxyear(1995) ///
             expsurvvars(Sstar*))

sts graph, by(agegrp)
frame marg_agegrp: addplot: line S_rs* tt, pstyle(p1line p2line p3line)     ///
                                      lpattern(dash..)                      /// 
                                      xtitle("Time from diagnosis (years)") ///
                                      ytitle("Proportion alive")            ///
                                      xline(10, lcolor(gs7) lpattern(dash)) ///
                                      legend(order(1 2 3))                  ///
                                      note("Dashed lines are model based")          

// (c)
// We will use the more recent period in the colon cancer data to calculate 
// life expectancy as a function of age. We will restrict to those aged 50+

use colon, clear
keep if year8594 ==1
keep if age>=50 

stset surv_mm, failure(status=1,2) scale(12) exit(time 120.5)

gen _age = int(min(age + _t,99))
gen _year = year(dx + _t*365.24)

merge m:1 sex _year _age using popmort, ///
          keepusing(rate) keep(match master)

// (i) Fit a model with non-linear and time-dependent effects of age and
//    non-proportional hazards. In addition, model the effect of sex, allowing
//    the effect of sex vary as a function of age (i.e. include an interaction)
//    and have non-proportional hazards. 
stpm3 @ns(age,df(3))##i.sex, scale(lncumhazard) df(5) ///
                             tvc(@ns(age,df(3)) i.sex) dftvc(3) bhazard(rate)

// (ii) Calculate life expectancy as a function of age for males and females.
cap frame drop age_le
frame create age_le 
frame age_le {
  range age 50 90 41
  gen t80 = 80 
  gen dx = mdy(1,1,1995)
  gen sex=.
  predict le_m le_f, rmst timevar(t80)  merge         ///
                     at1(sex 1, obsvalues)            ///
                     at2(sex 2, obsvalues)            ///
                     expsurv(using(popmort)           ///
                       agediag(age) datediag(dx)      ///
                       pmother(sex)                   ///
                       pmrate(rate)                   ///
                       pmage(_age) pmyear(_year)      ///
                       pmmaxage(99) pmmaxyear(1995)   ///
                       at1(sex 1) at2(sex 2)          ///
                       expvars(le_pop_m le_pop_f))
}

// (iii) Plot expected remaining life as a function of age
frame age_le {
  twoway (line le_m le_f age)                                                            ///
         (line le_pop_m le_pop_f age, pstyle(p1line p2line) lpattern(dash..)),           ///
         legend(order(1 "Males" 2 "Females" 3 "Males (expected)" 4 "Females (expected)") ///
         ring(0) pos(1))                                                                 ///   
         xtitle("Age at diagnosis")                                                      ///
         ytitle("Expected remaining life (years)")          
}

// (iv) Plot expected loss in life years as a function of age
frame age_le {
  gen lel_m = le_pop_m - le_m
  gen lel_f = le_pop_m - le_f
}

frame age_le {
  twoway (line lel_m lel_f age) ,                   ///
         legend(order(1 "Males" 2 "Females")        ///
         ring(0) pos(1))                            ///   
         xtitle("Age at diagnosis")                 ///
         ytitle("Loss in expected life (years)")          
}


// (v) Plot the proportion of life lost as a function of age
frame age_le {
  gen plel_m = lel_m/le_pop_m
  gen plel_f = lel_f/le_pop_f
}
frame age_le {
  twoway (line plel_m plel_f age) ,                   ///
         legend(order(1 "Males" 2 "Females")          ///
         ring(0) pos(1))                              ///   
         xtitle("Age at diagnosis")                   ///
         ytitle("Proportion of life lost")            ///
         ylabel(0(0.1)0.7, format(%3.1f))
}

// Plot the average age at death as function of age
frame age_le {
  gen agedeath_m = age + le_m
  gen agedeath_f = age + le_f
  gen agedeath_pop_m = age + le_pop_m
  gen agedeath_pop_f = age + le_pop_f
}
frame age_le {
  twoway (line agedeath_m agedeath_f  age)                               ///
         (line agedeath_pop_m agedeath_pop_f age, pstyle(p1line p2line)  ///
                lpattern(dash dash)),                                    ///
         legend(order(1 "Males" 2 "Females")                             ///
         ring(0) pos(1))                                                 ///   
         xtitle("Age at diagnosis")                                      ///
         ytitle("Proportion of life lost")                               ///
         ylabel(, format(%3.0f))                                         ///
         note("Colon cancer: solid lines, Population: dashed lines")
}







