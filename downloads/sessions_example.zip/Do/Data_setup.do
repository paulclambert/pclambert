// Data set-up
// Note starts in folder sessions is called from.

clear
use Data/EW_breast.dta

// merge in expected rates
stset survtime, failure(dead=1) id(id) 

gen age  = min(floor(agediag + _t),99)
gen year = year(datediag + _t*365.24)

merge m:1 age year dep sex region using Data/popmort_uk.dta, keep(match master)
drop _merge survprob

// save region specific data
levelsof region, local(regionlevels)
foreach region in `regionlevels' {
  preserve
  keep if region == `region'
  save data/survdata`region', replace
  restore
}

sleep 2000