
// Change the ROOT global macro to where you have saved the files.
clear all
global ROOT C:/Users/pala/GitHub/sessions/Testing/Breast_EW/webpage
cd ${ROOT}

// create data with info about Sessions, dofiles and arguments
clear 
input str20 dofile str30 SessionName  region str30 component
Data_setup.do          "Setup"           .    "data setup"
More_Data_setup.do     "Setup"           .    "data setup"
"" _wait_  . ""        
net_survival.do        "N & York"        1    "analysis"
net_survival.do        "Trent"           2    "analysis"    
net_survival.do        "Ang & Ox"        3    "analysis"    
net_survival.do        "N Thames"        4    "analysis"    
net_survival.do        "S Thames"        5    "analysis"    
net_survival.do        "S West"          6    "analysis"    
net_survival.do        "W Mids"          7    "analysis"    
net_survival.do        "N West"          8    "analysis"    
net_survival.do        "Wales"           9    "analysis"    
"" _wait_  . ""    
combine_results.do     "Combine"         .    "postestimation"
"" _wait_  . ""    
graphs_comparison.do   "Results"         .    "postestimation"
tables_simple.do       "Results"         .    "postestimation"
end


// List data
list SessionName dofile region component, noobs sepby(component) abbrev(12)


// do files stored in Do folder
replace dofile="do/" + dofile if SessionName != "_wait_"

// Initialize sessions
sessions init

// Run and monitor Stata sessions
sessions monitor,   names(SessionName)          /// Session name 
                    dofiles(dofile)             /// dofiles to run
                    arguments(region)           /// arguments
                    commondo("do/globals.do")   /// Common do files
                    logdelete                   /// delete existing logs
                    freememory(10)              /// free memory % needed
                    cpuload(70)                 /// start if <70% CPU load
                    maxsessions(4)              /// maxium number of sessions
                    update(3)                   /// update every 3 seconds
                    compress                    //  output table will fit on slide
               
// Use if statement to run a selection of sessions
sessions monitor if component=="postestimation", /// posestimation results only
                    names(SessionName)           /// Session name 
                    dofiles(dofile)              /// dofiles to run
                    arguments(region)            /// arguments
                    commondo("do/globals.do")    /// Common do files
                    logdelete                    /// delete existing logs
                    freememory(10)               /// free memory % needed
                    cpuload(70)                  /// start if <70% CPU load
                    maxsessions(4)               /// maxium number of sessions
                    update(3)                    //  update every 3 seconds
 
// Now create data to include mistake.do
// This demonstrates reporting of errors
clear 
input str20 dofile str30 SessionName  region str30 component
Data_setup.do          "Setup"           .    "data setup"
More_Data_setup.do     "Setup"           .    "data setup"
"" _wait_  . ""        
net_survival.do        "N & York"        1    "analysis"
net_survival.do        "Trent"           2    "analysis"    
"" _wait_  . ""    
combine_results.do     "Combine"         .    "postestimation"
"" _wait_  . ""    
mistake.do             "Results"         .    "postestimation"
graphs_comparison.do   "Results"         .    "postestimation"
tables_simple.do       "Results"         .    "postestimation"
end

list SessionName dofile region component, noobs sepby(component) abbrev(12)

// do files stored in Do folder
replace dofile="do/" + dofile if SessionName != "_wait_"


// Run and monitor Stata sessions
// This should produce an error with a single click to view the log file
sessions monitor,   names(SessionName)          /// Session name 
                    dofiles(dofile)             /// dofiles to run
                    arguments(region)           /// arguments
                    commondo("do/globals2.do")   /// Common do files
                    logdelete                   /// delete existing logs
                    freememory(10)              /// free memory % needed
                    cpuload(70)                 /// start if <70% CPU load
                    maxsessions(4)              /// maxium number of sessions
                    update(3)                   /// update every 3 seconds
                    compress                    //  output table will fit on slide

