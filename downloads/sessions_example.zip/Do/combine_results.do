// combine_results.do

clear
forvalues region = 1/$Nregions {
  di `region'
  append using data/relsurv_region`region'  
}
save results/relsurv_combined, replace