// globals.do
global Nregions 9