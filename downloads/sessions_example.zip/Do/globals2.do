// globals2.do
global Nregions 2