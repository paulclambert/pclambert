// graphs_comparison.do
use results/relsurv_combined, clear

forvalues region = 1/$Nregions {
         twoway (rarea Smod_lci Smod_uci time, color(red%30))     ///
         (line Smod time, color(red))                        ///
         (line PP_lci PP_uci time, color(blue blue) lpattern(dash dash))  ///
         (line PP time, color(blue))                                ///
         if region==`region',                                  ///
          name(region`region', replace)                        ///
          xtitle(Years from diagnosis)                         ///
          ytitle(Net survival)                                 ///
          title("Region `region'", ring(0))                             ///
          ylabel(, format(%3.1f))                              ///
          legend(order(2 "Model based" 4 "Non-parametric")     ///
                 pos(1) cols(2))                               ///
          nodraw

  local graphlist `graphlist' region`region'
}

grc1leg `graphlist', nocopies ycommon altshrink
graph export results/graphs/survival_compare_regions.pdf, replace