// mistake.do
use results/relsurv_combined, clear

// The following line is a deliberate mistake
XXX is not a Stata command
