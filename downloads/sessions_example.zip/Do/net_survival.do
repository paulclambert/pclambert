// net survival.do
local region `1'

// for development
if "`region'" == "" local region 1

use data/survdata`region', clear

// non-parametric estimator

stpp RS_pp using "Data/popmort_uk", ///
                agediag(agediag) datediag(datediag)         ///
                pmother(sex region dep) list(0(`=1/12')10)  ///
                pmage(age) pmyear(year)                     ///
                frame(stpp, replace)
frame stpp: gen idn = _n
// model
stpm3 @ns(agediag, df(3)), scale(lncumhazard) df(5)           ///
                           tvc(@ns(agediag, df(3))) dftvc(3)  ///
                           bhazard(rate)

// predict model estimates at stpp evaluation times
gen idn = _n
frlink 1:1 idn, frame(stpp)
frget time, from(stpp)

standsurv Smod, survival at1(.) ci timevar(time) frame(stpm3, replace)

frame stpp {
  frlink 1:1 time, frame(stpm3)
  frget Smod*, from (stpm3)
  gen region = `region'
  save data/relsurv_region`region', replace
}


