// tables_simple.do
use results/relsurv_combined, clear

list region Smod PP if time==10, noobs




