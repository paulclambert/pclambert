Example of using the Stata sessions command.

You just need to edit and run Define_and_start_sessions.do file.

Change the path defined in the global macro on line 4